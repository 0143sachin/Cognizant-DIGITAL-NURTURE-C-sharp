using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals3             //DO NOT CHANGE the name of namespace
{
    public class Program                 //DO NOT CHANGE the name of class 'Program'
    {
        public static void Main(string[] args)       //DO NOT CHANGE 'Main' Signature
        {
           
           //Fill the code here
            Console.Write("Enter letter  1 : ");
            string c=Console.ReadLine();
            Console.Write("Enter letter  2 : ");
            string a=Console.ReadLine();
            Console.Write("Enter letter  3 : ");
            string s1=Console.ReadLine();
            Console.Write("Enter letter  4 : ");
            string a1=Console.ReadLine();
            Console.Write("Enter letter  5 : ");
            string b=Console.ReadLine();
            Console.Write("Enter letter  6 : ");
            string l=Console.ReadLine();
            Console.Write("Enter letter  7 : ");
            string a2=Console.ReadLine();
            Console.Write("Enter letter  8 : ");
            string n=Console.ReadLine();
            Console.Write("Enter letter  9 : ");
            string c1=Console.ReadLine();
            Console.Write("Enter letter  10 : ");
            string a3=Console.ReadLine();
            if(c.Equals("c")){
                Console.WriteLine("Enter letter  1 : c");  
                }else{
                    Console.WriteLine("The spelling is wrong");
                }
            if(a.Equals("a")){
                Console.WriteLine("Enter letter  2 : a");  
                }else{
                    Console.WriteLine("The spelling is wrong");
                }
            if(s1.Equals("s")){
                Console.WriteLine("Enter letter  3 : s");  
                }else{
                    Console.WriteLine("The spelling is wrong");
                    }
            if(a1.Equals("a")){
                Console.WriteLine("Enter letter  4 : a");  
                }else{
                    Console.WriteLine("The spelling is wrong");
                }
            if(b.Equals("b")){
                Console.WriteLine("Enter letter  5 : b");  
                }else{
                    Console.WriteLine("The spelling is wrong");
                }
            if(l.Equals("l")){
                Console.WriteLine("Enter letter  6 : l");  
                }else{
                    Console.WriteLine("The spelling is wrong");
                    }
            if(a2.Equals("a")){
                Console.WriteLine("Enter letter  7 : a");  
                }else{
                    Console.WriteLine("The spelling is wrong");
                    }
            if(n.Equals("n")){
                Console.WriteLine("Enter letter  8 : n");  
                }else{
                    Console.WriteLine("The spelling is wrong");
                    }
            if(c1.Equals("c")){
                Console.WriteLine("Enter letter  9 : c");  
                }else{
                    Console.WriteLine("The spelling is wrong");
                    }
            if(a3.Equals("a")){
                Console.WriteLine("Enter letter  10 : a");  
                }else{
                    Console.WriteLine("The spelling is wrong");

        }
        }
    }
}
