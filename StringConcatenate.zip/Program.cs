using System;
namespace hello{
    class project{
        static void Main(String[] args)
        {
            Console.WriteLine("Enter first name");
            string fname = Console.ReadLine();
            Console.WriteLine("Enter last name");
            string lname = Console.ReadLine();
            
            Console.WriteLine("Full name : "+fname+" "+lname);
        }
    }
}

