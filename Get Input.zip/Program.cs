using System;
namespace program
{
    class program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your first name");
            string fname = Console.ReadLine();
            Console.WriteLine("Enter your last name");
            String lname = Console.ReadLine();
            
            Console.WriteLine($"Your full name is {fname} {lname}");
            Console.ReadLine();
            
        }
    }
}