using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals2           //DO NOT Change namespace name
{
    public class Program              //DO NOT Change class 'Program' name
    {
        public static void Main(string[] args)    //DO NOT Change 'Main' method Signature
        {
            //Implement your code here
            Console.WriteLine("Enter the number of pizzas bought : ");
            int pizza = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number of puffs bought : ");
            int puff = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number of pepsi bought : ");
            int pepsi = Convert.ToInt32(Console.ReadLine());
            
            int t_pizza = pizza*200;
            int t_puff = puff*40;
            int t_pepsi = pepsi*120;
            double gst = 0.12*(t_pepsi+t_puff+t_pizza);
            double cess = 0.05*(t_pepsi+t_puff+t_pizza);
            double total = (t_pepsi+ t_puff+ t_pizza);
            
            Console.WriteLine("Bill Details");
            Console.WriteLine("Cost of Pizzas :"+t_pizza);
            Console.WriteLine("Cost of Puffs :"+t_puff);
            Console.WriteLine("Cost of Pepsis :"+t_pepsi);
            Console.WriteLine("GST 12% :"+gst);
            Console.WriteLine("CESS 5% :"+cess);
            Console.WriteLine("Total Price :"+total);
            
        }
    }
}
