//Implement code here

//Implement code here
     using System;
     public class Account
     {
         private int id;
         private string accountType;
         private double balance;
         
        public int Id
        {
            get
            {
                return this.id;
            }
            set
            {
                this.id=value;
            }
        }
        
        public string AccountType
        {
            get
            {
                return this.accountType;
            }
            set
            {
                this.accountType=value;
            }
        }
        
        public double Balance
        {
            get
            {
                return this.balance;
            }
            set
            {
                this.balance=value;
            }
        }
        
        public Account()
        {}
        
        public Account(int id , string accountType , double balance)
        {
            this.Id=id;
            this.AccountType=accountType;
            this.Balance=balance;
        }
        
        public bool WithDraw(double amount)
        {
            if(balance>amount)
            {
                balance=balance-amount;
                return true;
            }
            else
            {
                return false;
            }
        }
        
        public string GetDetails()
        {
            string str = string.Format("Account Id: {0}\nAccount Type: {1}\nBalance: {2}",id,accountType,balance);
            return str;
        }
    }
    
    public class program
    {
        public static void Main()
        {
            Console.WriteLine("Enter account id");
            int i=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter account type");
            string acc=Console.ReadLine();
            Console.WriteLine("Enter account balance");
            double bal=Convert.ToDouble(Console.ReadLine());
            Account ac2=new Account(i,acc,bal);
            string str2=ac2.GetDetails();
            Console.WriteLine(str2);
            Console.WriteLine("Enter amount to withdraw");
            double with = Convert.ToDouble(Console.ReadLine());
            bool calling = ac2.WithDraw(with);
            if(calling)
                Console.WriteLine("New Balance;"+(bal-with));
       }
   }